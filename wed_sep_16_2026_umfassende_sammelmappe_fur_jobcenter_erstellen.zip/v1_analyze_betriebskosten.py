#!/usr/bin/env python3
import argparse
import glob
import os
import re
from collections import defaultdict
from datetime import datetime
from difflib import SequenceMatcher

import fitz
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

MONEY_RE = re.compile(r'(-?[0-9]{1,3}(?:[\. ]?[0-9]{3})*,[0-9]{2})')
LABELS = {
    'betriebskosten': ['betriebskosten', 'betriebs', 'betriebskost', 'betriebs- & heizkostenabrechnung', 'barebskonten'],
    'heizkosten': ['heizkosten', 'heizkon', 'heizko', 'heizkonien'],
    'gesamtkosten': ['gesamtkosten', 'gesamtkost', 'gesamtkosten', 'gesamt verteil', 'gesamtverteiler'],
    'guthaben': ['guthaben', 'guthabenbetrag', 'guthaben in'],
}
FUZZY_THRESHOLD = 0.75


def normalize_text(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r'[^a-z0-9äöüß]+', '', text)
    return text


def matches_label(line: str, keyword: str) -> bool:
    normalized = normalize_text(line)
    for candidate in LABELS[keyword]:
        candidate_norm = normalize_text(candidate)
        if candidate_norm and candidate_norm in normalized:
            return True
        if SequenceMatcher(None, normalized, candidate_norm).ratio() >= FUZZY_THRESHOLD:
            return True
    return False


def parse_money(value: str) -> float:
    cleaned = value.replace('.', '').replace(' ', '').replace(',', '.')
    try:
        return float(cleaned)
    except ValueError:
        raise


def find_label_values(lines, keyword):
    candidates = []
    for idx, line in enumerate(lines):
        if matches_label(line, keyword):
            values = []
            for follow_idx in range(idx + 1, min(idx + 5, len(lines))):
                values.extend(MONEY_RE.findall(lines[follow_idx]))
                if values:
                    break
            if values:
                candidates.append((idx, values))
    return candidates


def extract_summary_region(lines):
    header_idx = next((idx for idx, line in enumerate(lines) if 'zusammenfassung' in line.lower()), None)
    if header_idx is None:
        return lines
    end_idx = len(lines)
    for idx in range(header_idx + 1, len(lines)):
        if 'aus der abrechnung' in lines[idx].lower():
            end_idx = idx
            break
    return lines[header_idx:end_idx]


def extract_summary_from_text(text: str):
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    summary_lines = extract_summary_region(lines)
    summary = {}
    notes = []
    for keyword in LABELS:
        matches = find_label_values(summary_lines, keyword)
        if matches:
            summary[keyword] = matches[0][1][0]
        else:
            summary[keyword] = None
            notes.append(f'Could not find a confident {keyword} value in summary text.')
    return summary, notes


def extract_labels_from_block(text: str):
    labels = []
    for line in text.splitlines():
        normalized_line = line.lower()
        if 'abrechnung' in normalized_line and 'betrieb' in normalized_line:
            continue
        for keyword in LABELS:
            if matches_label(line, keyword) and keyword not in labels:
                labels.append(keyword)
    return labels


def block_distance(source, target):
    x0, y0, x1, y1 = source[:4]
    ox0, oy0, ox1, oy1 = target[:4]

    if ox1 < x0:
        dx = x0 - ox1
    elif ox0 > x1:
        dx = ox0 - x1
    else:
        dx = 0

    if oy1 < y0:
        dy = y0 - oy1
    elif oy0 > y1:
        dy = oy0 - y1
    else:
        dy = 0

    return dx * 1.5 + dy


def find_summary_page(doc):
    for page in doc:
        text = page.get_text().lower()
        if 'zusammenfassung der abrechnung' in text or 'ihre gesamtkosten' in text or 'summe gesamtkosten' in text:
            return page
    return None


def extract_summary_from_page_text(page):
    text = page.get_text()
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    start_idx = next((idx for idx, line in enumerate(lines) if 'zusammenfassung' in line.lower()), None)
    if start_idx is None:
        return {k: None for k in LABELS}, []

    section = lines[start_idx:]
    label_order = []
    guthaben_idx = None
    for idx, line in enumerate(section):
        lower = line.lower()
        if 'aus der abrechnung' in lower:
            break
        if matches_label(line, 'betriebskosten') and 'abrechnung' not in lower:
            label_order.append('betriebskosten')
        elif matches_label(line, 'heizkosten') and 'abrechnung' not in lower:
            label_order.append('heizkosten')
        elif matches_label(line, 'gesamtkosten'):
            label_order.append('gesamtkosten')
        if matches_label(line, 'guthaben'):
            guthaben_idx = idx

    summary = {k: None for k in LABELS}
    if label_order:
        label_values = []
        for line in section:
            lower = line.lower()
            if 'ihr kostenanteil' in lower or 'ergebnis' in lower or 'aus der abrechnung' in lower:
                continue
            if 'gesamtkosten gesamtverteiler' in lower:
                continue
            label_values.extend(MONEY_RE.findall(line))
            if len(label_values) >= len(label_order):
                break
        for idx, key in enumerate(label_order):
            if idx < len(label_values):
                summary[key] = label_values[idx]

    if guthaben_idx is not None:
        for line in section[guthaben_idx:]:
            values = MONEY_RE.findall(line)
            if values:
                summary['guthaben'] = values[0]
                break

    notes = []
    for key in LABELS:
        if summary[key] is None:
            notes.append(f'Could not find a confident {key} value in page summary text.')
    return summary, notes


def extract_summary_from_page_blocks(page):
    blocks = sorted(page.get_text('blocks'), key=lambda block: (block[1], block[0]))
    summary = {k: None for k in LABELS}
    notes = []

    header_block = next((block for block in blocks if 'zusammenfassung der abrechnung' in block[4].lower()), None)
    if header_block:
        summary_top = header_block[1]
        summary_bottom = None
        for block in blocks:
            if 'aus der abrechnung' in block[4].lower():
                summary_bottom = block[1]
                break
        if summary_bottom is None:
            summary_bottom = summary_top + 260
        summary_blocks = [block for block in blocks if block[1] >= summary_top and block[1] <= summary_bottom]
    else:
        summary_blocks = blocks

    # First pass: find blocks that already contain both labels and values.
    for block in summary_blocks:
        text = block[4].strip()
        if not text:
            continue
        labels = extract_labels_from_block(text)
        if not labels:
            continue
        values = MONEY_RE.findall(text)
        if labels and values:
            for idx, label in enumerate(labels):
                if summary[label] is None and idx < len(values):
                    summary[label] = values[idx]

    # Second pass: search for the nearest numeric block to label-only blocks.
    for block in summary_blocks:
        text = block[4].strip()
        if not text:
            continue
        labels = extract_labels_from_block(text)
        if not labels:
            continue
        if all(summary[label] for label in labels):
            continue

        value_candidates = []
        for other in summary_blocks:
            if other is block:
                continue
            values = MONEY_RE.findall(other[4])
            if not values:
                continue
            vertical_gap = other[1] - block[3]
            if vertical_gap > 90 and 'guthaben' not in labels:
                continue
            value_candidates.append((block_distance(block, other), other, values))
        value_candidates.sort(key=lambda item: (int(item[1][1] / 20), item[1][0]))

        nearby_values = []
        for _, other, values in value_candidates:
            nearby_values.extend(values)
            if len(nearby_values) >= len(labels):
                break

        if nearby_values:
            for idx, label in enumerate(labels):
                if summary[label] is None and idx < len(nearby_values):
                    summary[label] = nearby_values[idx]

    # Explicit Guthaben search when not found yet.
    if summary['guthaben'] is None:
        for block in summary_blocks:
            text = block[4].strip()
            if matches_label(text, 'guthaben'):
                values = MONEY_RE.findall(text)
                if not values:
                    x0, y0, x1, y1 = block[:4]
                    for other in summary_blocks:
                        if other is block:
                            continue
                        if other[1] >= y0 and other[1] <= y1 + 100 and other[0] >= x0 - 20:
                            values.extend(MONEY_RE.findall(other[4]))
                if values:
                    summary['guthaben'] = values[0]
                    break

    return summary, notes


def extract_summary_from_pdf(path: str):
    doc = fitz.open(path)
    summary = {k: None for k in LABELS}
    notes = []
    page = None
    for candidate in doc:
        text = candidate.get_text()
        if 'zusammenfassung der abrechnung' in text.lower() or 'ihre gesamtkosten' in text.lower() or 'summe gesamtkosten' in text.lower():
            page = candidate
            break
    if page:
        text_summary, text_notes = extract_summary_from_page_text(page)
        for key in summary:
            summary[key] = text_summary.get(key)
        notes.extend(text_notes)
        if any(value is None for value in summary.values()):
            block_summary, block_notes = extract_summary_from_page_blocks(page)
            for key in summary:
                if summary[key] is None:
                    summary[key] = block_summary.get(key)
            notes.extend(block_notes)

    full_text = extract_text_from_pdf(path)
    fallback_summary, fallback_notes = extract_summary_from_text(full_text)
    for key in summary:
        if summary[key] is None:
            summary[key] = fallback_summary.get(key)
    notes.extend(fallback_notes)
    return summary, notes


def extract_text_from_pdf(path: str) -> str:
    doc = fitz.open(path)
    text = []
    for page in doc:
        extracted = page.get_text()
        if extracted:
            text.append(extracted)
    return '\n'.join(text)


def path_to_year(path: str) -> int:
    base = os.path.basename(path)
    m = re.search(r'_(\d{4})_OCR\.pdf$', base)
    if m:
        return int(m.group(1))
    m = re.search(r'_(\d{4})\.pdf$', base)
    if m:
        return int(m.group(1))
    return None


def ratio(a, b):
    if a is None or b is None:
        return None
    if b == 0:
        return float('inf') if a != 0 else 1.0
    return abs(a - b) / abs(b)


def build_report(data, output_path):
    doc = SimpleDocTemplate(output_path, pagesize=letter, leftMargin=0.75 * inch, rightMargin=0.75 * inch,
                            topMargin=0.75 * inch, bottomMargin=0.75 * inch)
    styles = getSampleStyleSheet()
    normal = styles['Normal']
    heading = styles['Heading1']
    heading2 = styles['Heading2']
    small = ParagraphStyle('small', parent=normal, fontSize=10, leading=12)

    elements = []
    elements.append(Paragraph('Betriebskosten PDF Analysis Report', heading))
    elements.append(Spacer(1, 12))
    elements.append(Paragraph(f'Report generated on {datetime.now():%Y-%m-%d %H:%M:%S}', normal))
    elements.append(Spacer(1, 12))
    elements.append(Paragraph('This report analyzes OCR-extracted documents for year-over-year operating cost consistency, label extraction reliability, and suspicious patterns that may indicate anomalies in the scanned texts.', normal))
    elements.append(Spacer(1, 14))

    overview_rows = [
        ['PDF files examined', str(len(data))],
        ['Years covered', ', '.join(str(year) for year in sorted(data))],
    ]
    overview_table = Table(overview_rows, colWidths=[2.75 * inch, 3.75 * inch])
    overview_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.whitesmoke),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.black),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    elements.append(overview_table)
    elements.append(Spacer(1, 16))

    summary_table_rows = [['Year', 'Betriebskosten', 'Heizkosten', 'Gesamtkosten', 'Guthaben', 'Notes']]
    for year in sorted(data):
        item = data[year]
        summary_table_rows.append([
            str(year),
            item.get('betriebskosten') or 'N/A',
            item.get('heizkosten') or 'N/A',
            item.get('gesamtkosten') or 'N/A',
            item.get('guthaben') or 'N/A',
            ' '.join(item.get('notes', [])) or 'OK',
        ])
    summary_table = Table(summary_table_rows, colWidths=[0.75*inch, 1.25*inch, 1.25*inch, 1.25*inch, 1.25*inch, 2.0*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#d9d9d9')),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
    ]))
    elements.append(Paragraph('Extracted values per year', heading2))
    elements.append(summary_table)
    elements.append(Spacer(1, 16))

    anomalies = []
    for year in sorted(data):
        notes = data[year].get('notes') or []
        if notes:
            anomalies.append(f"{year}: {'; '.join(notes)}")

    if anomalies:
        elements.append(Paragraph('Detected anomalies and extraction issues', heading2))
        elements.append(Spacer(1, 8))
        for note in anomalies:
            elements.append(Paragraph(f'• {note}', normal))
            elements.append(Spacer(1, 4))
    else:
        elements.append(Paragraph('No anomalies were detected in the extracted summary values.', normal))

    doc.build(elements)


def collect_yearly_anomalies(data):
    anomalies = []
    years = sorted(data)
    for idx, year in enumerate(years):
        entry = data[year]
        if entry.get('betriebskosten') is None:
            anomalies.append(f'{year}: Missing Betriebskosten value.')
        if entry.get('gesamtkosten') is None:
            anomalies.append(f'{year}: Missing Gesamtkosten value.')
        if entry.get('heizkosten') is None:
            anomalies.append(f'{year}: Missing Heizkosten value.')
        if entry.get('guthaben') is None:
            anomalies.append(f'{year}: Missing Guthaben value.')
        if entry.get('betriebskosten') and entry.get('heizkosten') and entry.get('gesamtkosten'):
            try:
                betriebs = parse_money(entry['betriebskosten'])
                heiz = parse_money(entry['heizkosten'])
                gesamt = parse_money(entry['gesamtkosten'])
                if abs((betriebs + heiz) - gesamt) > max(1.0, 0.02 * gesamt):
                    anomalies.append(
                        f"{year}: Reported Gesamtkosten ({entry['gesamtkosten']}) does not match Betriebskosten + Heizkosten ({entry['betriebskosten']} + {entry['heizkosten']})."
                    )
            except ValueError:
                anomalies.append(f'{year}: Could not parse numeric values for consistency check.')
        if idx > 0:
            prev_year = years[idx - 1]
            prev = data[prev_year]
            for key in ['betriebskosten', 'heizkosten', 'gesamtkosten']:
                if prev.get(key) and entry.get(key):
                    try:
                        prev_val = parse_money(prev[key])
                        current_val = parse_money(entry[key])
                        if prev_val != 0 and abs(current_val - prev_val) / prev_val > 0.5:
                            anomalies.append(
                                f'{year}: {key} moved by more than 50% from {prev_year} ({prev[key]} → {entry[key]}).'
                            )
                        identical_span = 1
                        scan_idx = idx - 1
                        while scan_idx >= 0 and data[years[scan_idx]].get(key) == entry[key]:
                            identical_span += 1
                            scan_idx -= 1
                        if identical_span >= 3:
                            anomalies.append(
                                f'{year}: {key} has been identical for {identical_span} consecutive years ending in {year} ({entry[key]}).'
                            )
                    except ValueError:
                        anomalies.append(f'{year}: Could not compare {key} values to prior year.')
    return sorted(set(anomalies))


def main():
    parser = argparse.ArgumentParser(description='Analyze Betriebskosten OCR PDFs for inconsistencies and generate a PDF report.')
    parser.add_argument('directory', nargs='?', default='.', help='Directory containing Betriebskosten OCR PDF files')
    parser.add_argument('--output', '-o', default='Betriebskosten_Analysis_Report.pdf', help='PDF output path')
    args = parser.parse_args()

    pdf_paths = sorted(glob.glob(os.path.join(args.directory, '*_OCR.pdf')))
    if not pdf_paths:
        raise SystemExit('No OCR PDF files found in the requested directory.')

    data = {}
    for path in pdf_paths:
        year = path_to_year(path)
        if year is None:
            continue
        summary, notes = extract_summary_from_pdf(path)
        data[year] = {
            'file': path,
            **summary,
            'notes': notes,
        }

    extra_anomalies = collect_yearly_anomalies(data)
    for year in data:
        data[year]['notes'].extend([note for note in extra_anomalies if note.startswith(str(year) + ':')])

    build_report(data, args.output)
    print(f'Analysis completed and written to {args.output}')


if __name__ == '__main__':
    main()
