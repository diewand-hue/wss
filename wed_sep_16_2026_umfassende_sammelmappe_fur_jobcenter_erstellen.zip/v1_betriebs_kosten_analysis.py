import json
import math
import os
import re
from datetime import datetime
from typing import Optional

from pypdf import PdfReader

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PDF_PATTERN = re.compile(r'^Betriebskosten_(\d{4})_OCR\.pdf$', re.IGNORECASE)
CURRENCY_RE = re.compile(r'(-?[0-9][0-9\.\s,]*[0-9])\s*(?:€|EUR)')

FIELD_LABELS = {
    'operating_cost': [r'\bBetriebskosten\b', r'\bBetriebskostenabrechnung\b'],
    'heating_cost': [r'\bHeiz(?:-| |)kosten\b', r'\bHeiz-.*Warmwasser\b', r'\bWarmwasser\b'],
    'total_cost': [r'\bGesamtkosten\b', r'\bGesamtkosten Gesamtverteiler\b'],
    'advance_payment': [r'\bVorauszahlung\b', r'\bVorauszahl\b', r'\bVorausrw\b', r'\bIhre Vorauszahlung\b'],
    'credit': [r'\bGuthaben\b'],
    'debit': [r'\bNachzahlung\b', r'\bNachzahrung\b'],
    'result': [r'\bAbrechnungsergebnis\b', r'\bNach Ergebnis\b'],
}


class ParseError(Exception):
    pass


OCR_REPLACEMENTS = {
    r'\bVorausrw\b': 'Vorauszahlung',
    r'\bVorausrw\s*dung\b': 'Vorauszahlung',
    r'\bVorauszahlung\s*dung\b': 'Vorauszahlung',
    r'\bAbrechnungszoltraum\b': 'Abrechnungszeitraum',
    r'\bKostenantel\b': 'Kostenanteil',
    r'\bKostenantel\s*hre\b': 'Kostenanteil Ihre',
    r'\bBarebskonten\b': 'Betriebskosten',
    r'\bHeizkonien\b': 'Heizkosten',
    r'\bthre\b': 'Ihre',
    r'\bIhr Anteil\b': 'Ihr Kostenanteil',
    r'\bNachzahrung\b': 'Nachzahlung',
    r'\bGuthaben\s*\|\|\b': 'Guthaben',
}


def normalize_line(line: str) -> str:
    line = re.sub(r'\s+', ' ', line.strip())
    for wrong, right in OCR_REPLACEMENTS.items():
        line = re.sub(wrong, right, line, flags=re.IGNORECASE)
    return line


def parse_money(raw: str) -> Optional[float]:
    if not raw:
        return None

    text = raw.strip().replace('\xa0', ' ').strip()
    if not text:
        return None

    raw_text = text
    if ' ' in raw_text and ',' not in raw_text and '.' not in raw_text:
        groups = re.split(r'\s+', raw_text)
        if all(group.isdigit() for group in groups):
            if len(groups[-1]) == 2 and len(groups) > 1:
                text = ''.join(groups[:-1]) + '.' + groups[-1]
            else:
                text = ''.join(groups)
    else:
        text = raw_text.replace(' ', '')

    # Fix OCR style dotted euro amounts like "1.176.00" -> "1176.00".
    if text.count('.') > 1 and ',' not in text:
        parts = text.split('.')
        if all(part.isdigit() for part in parts) and len(parts[-1]) == 2:
            text = ''.join(parts[:-1]) + '.' + parts[-1]

    if ',' in text and '.' in text:
        if text.rfind(',') > text.rfind('.'):
            text = text.replace('.', '')
            text = text.replace(',', '.')
        else:
            text = text.replace(',', '')
    elif ',' in text:
        parts = text.split(',')
        if len(parts[-1]) in (1, 2):
            text = text.replace('.', '')
            text = text.replace(',', '.')
        else:
            text = text.replace(',', '')
    elif '.' in text:
        if text.count('.') > 1:
            parts = text.split('.')
            if len(parts[-1]) == 2 and all(part.isdigit() for part in parts):
                text = ''.join(parts[:-1]) + '.' + parts[-1]
            else:
                text = text.replace('.', '')
        elif len(text.split('.')[-1]) != 2:
            text = text.replace('.', '')

    try:
        return float(text)
    except ValueError:
        return None


def get_amounts_from_line(line: str) -> list[float]:
    amounts = []
    for match in CURRENCY_RE.finditer(line):
        value = parse_money(match.group(1))
        if value is not None:
            amounts.append(value)
    return amounts


def get_label_block_amount_rows(lines: list[str], label_re: str, stop_re: Optional[str] = None, max_lookahead: int = 6) -> list[list[float]]:
    for index, line in enumerate(lines):
        if re.search(label_re, line, re.IGNORECASE):
            rows = []
            for lookahead in range(1, max_lookahead + 1):
                if index + lookahead >= len(lines):
                    break
                candidate = lines[index + lookahead]
                if stop_re and re.search(stop_re, candidate, re.IGNORECASE):
                    break
                amounts = get_amounts_from_line(candidate)
                if amounts:
                    rows.append(amounts)
            return rows
    return []


def choose_total_from_amount_rows(rows: list[list[float]]) -> Optional[float]:
    if not rows:
        return None
    if any(len(row) > 1 for row in rows):
        return rows[-1][-1]
    singles = [row[0] for row in rows if row]
    if not singles:
        return None
    if len(singles) == 1:
        return singles[0]
    if abs(singles[-1] - sum(singles[:-1])) < 1.00:
        return singles[-1]
    return sum(singles)


def choose_last_total(rows: list[list[float]]) -> Optional[float]:
    if not rows:
        return None
    return rows[-1][-1]


def choose_column_total(rows: list[list[float]], column: int = 0) -> Optional[float]:
    if not rows:
        return None
    valid = [row[column] for row in rows if len(row) > column]
    if not valid:
        return None
    if len(valid) == 1:
        return valid[0]
    if abs(valid[-1] - sum(valid[:-1])) < 1.00:
        return valid[-1]
    return sum(valid)


def choose_advance_total(rows: list[list[float]]) -> Optional[float]:
    if not rows:
        return None
    if all(len(row) >= 2 for row in rows):
        # Table-style rows usually store a final total in the last column.
        return rows[-1][-1]
    if all(len(row) == 1 for row in rows):
        # Multi-row advance sections commonly show the last payment target in the final row.
        return rows[-1][0]
    if len(rows) == 1 and len(rows[0]) == 2:
        return rows[0][-1]
    return choose_last_total(rows)


def parse_costs_from_summary_table(lines: list[str]) -> dict[str, Optional[float]]:
    table_rows = extract_amount_table_after_anchor(
        lines,
        r'Vorauszahlungsart.*Abrechnungs.*Ihre Gesamtkosten|Ihre Gesamtkosten|Zusammenfassung der Abrechnung',
        stop_re=r'Ihre Vorauszahlung|Vorauszahlung|Nach Ergebnis|Nachzahlung|Guthaben|Abrechnungsergebnis',
        max_lookahead=15,
    )
    costs: dict[str, Optional[float]] = {
        'operating_cost': None,
        'heating_cost': None,
        'total_cost': None,
    }
    if not table_rows:
        return costs

    if len(table_rows) >= 1 and table_rows[0]:
        costs['operating_cost'] = table_rows[0][0]
    if len(table_rows) >= 2 and table_rows[1]:
        costs['heating_cost'] = table_rows[1][0]
    if len(table_rows) >= 3 and table_rows[2]:
        costs['total_cost'] = table_rows[2][0]

    if costs['total_cost'] is None and costs['operating_cost'] is not None and costs['heating_cost'] is not None:
        costs['total_cost'] = costs['operating_cost'] + costs['heating_cost']

    return costs


def find_multiline_anchor(lines: list[str], anchor_re: str) -> Optional[int]:
    for index, line in enumerate(lines):
        if re.search(anchor_re, line, re.IGNORECASE):
            return index
        if index + 1 < len(lines):
            combined = f'{line} {lines[index + 1]}'
            if re.search(anchor_re, combined, re.IGNORECASE):
                return index
    return None


def find_multiline_anchor_end(lines: list[str], anchor_re: str) -> int:
    for index, line in enumerate(lines):
        if re.search(anchor_re, line, re.IGNORECASE):
            return index + 1
        if index + 1 < len(lines):
            combined = f'{line} {lines[index + 1]}'
            if re.search(anchor_re, combined, re.IGNORECASE):
                return index + 2
    return 0


def extract_amount_table_after_anchor(
    lines: list[str],
    anchor_re: str,
    stop_re: Optional[str] = None,
    min_rows: int = 1,
    max_lookahead: int = 12,
) -> list[list[float]]:
    start_index = find_multiline_anchor_end(lines, anchor_re)
    if start_index == 0:
        return []

    rows: list[list[float]] = []
    consecutive_non_amounts = 0
    for lookahead in range(0, max_lookahead):
        if start_index + lookahead >= len(lines):
            break
        candidate = lines[start_index + lookahead]

        if stop_re and re.search(stop_re, candidate, re.IGNORECASE):
            break

        row_amounts = get_amounts_from_line(candidate)
        if row_amounts:
            rows.append(row_amounts)
            consecutive_non_amounts = 0
            continue

        consecutive_non_amounts += 1
        if rows and consecutive_non_amounts >= 5:
            break

    return rows if len(rows) >= min_rows else []


def find_amounts_after_anchor(lines: list[str], anchor_re: str, min_amounts: int = 2, max_lookahead: int = 10) -> list[float]:
    index = find_multiline_anchor(lines, anchor_re)
    if index is None:
        return []

    amounts: list[float] = []
    for lookahead in range(1, max_lookahead + 1):
        if index + lookahead >= len(lines):
            break
        candidate = lines[index + lookahead]
        amounts.extend(get_amounts_from_line(candidate))
        if len(amounts) >= min_amounts:
            return amounts
    return []


def find_amounts_from_index(lines: list[str], start_index: int, prefer_last: bool = False, max_lookahead: int = 6, stop_re: Optional[str] = None) -> Optional[float]:
    amounts: list[float] = []
    for lookahead in range(0, max_lookahead + 1):
        if start_index + lookahead >= len(lines):
            break
        candidate = lines[start_index + lookahead]
        if stop_re and re.search(stop_re, candidate, re.IGNORECASE):
            break
        amounts.extend(get_amounts_from_line(candidate))
    if not amounts:
        return None
    return amounts[-1] if prefer_last else amounts[0]


def find_amount_for_label(lines: list[str], label_re: str, prefer_last: bool = False, max_lookahead: int = 6, stop_re: Optional[str] = None) -> Optional[float]:
    for index, line in enumerate(lines):
        if re.search(label_re, line, re.IGNORECASE):
            inline_amounts = get_amounts_from_line(line)
            if inline_amounts:
                return inline_amounts[-1] if prefer_last else inline_amounts[0]
            return find_amounts_from_index(lines, index + 1, prefer_last=prefer_last, max_lookahead=max_lookahead, stop_re=stop_re)
        if index + 1 < len(lines):
            combined = f'{line} {lines[index + 1]}'
            if re.search(label_re, combined, re.IGNORECASE):
                return find_amounts_from_index(lines, index + 2, prefer_last=prefer_last, max_lookahead=max_lookahead, stop_re=stop_re)
    return None


def extract_summary_lines(lines: list[str]) -> list[str]:
    summary_anchors = [
        r'Zusammenfassung der Abrechnung',
        r'Vorauszahlungsart Abrechnungszeitraum Ihre Gesamtkosten',
        r'Nachfolgend wurden die einzelnen Kostenpositionen zusammengefasst',
        r'Ihr Kostenanteil Ihre Vorauszahlung',
        r'Abrechnungsergebnis',
        r'Ihre Vorauszahlung',
    ]

    for anchor in summary_anchors:
        for index, line in enumerate(lines):
            if re.search(anchor, line, re.IGNORECASE):
                start = max(0, index - 2)
                end = min(len(lines), index + 25)
                return lines[start:end]

    if len(lines) > 40:
        return lines[-40:]

    return lines


def find_amounts_after_label(lines: list[str], start_index: int, prefer_last: bool = False, max_lookahead: int = 6, stop_re: Optional[str] = None) -> Optional[float]:
    amounts: list[float] = []
    for lookahead in range(0, max_lookahead + 1):
        if start_index + lookahead >= len(lines):
            break
        candidate = lines[start_index + lookahead]
        if stop_re and re.search(stop_re, candidate, re.IGNORECASE):
            break
        amounts.extend(get_amounts_from_line(candidate))
    if not amounts:
        return None
    return amounts[-1] if prefer_last else amounts[0]


def find_amount_for_label(lines: list[str], label_re: str, prefer_last: bool = False, max_lookahead: int = 6, stop_re: Optional[str] = None) -> Optional[float]:
    for index, line in enumerate(lines):
        if re.search(label_re, line, re.IGNORECASE):
            return find_amounts_after_label(lines, index + 1, prefer_last=prefer_last, max_lookahead=max_lookahead, stop_re=stop_re)
        if index + 1 < len(lines):
            combined = f'{line} {lines[index + 1]}'
            if re.search(label_re, combined, re.IGNORECASE):
                return find_amounts_after_label(lines, index + 2, prefer_last=prefer_last, max_lookahead=max_lookahead, stop_re=stop_re)
    return None


def parse_summary_fields(text: str) -> dict[str, Optional[float]]:
    lines = [normalize_line(line) for line in text.splitlines() if normalize_line(line)]
    summary_lines = extract_summary_lines(lines)
    parsed = {
        'operating_cost': None,
        'heating_cost': None,
        'total_cost': None,
        'advance_payment': None,
        'credit': None,
        'debit': None,
        'result': None,
    }

    cost_candidates = parse_costs_from_summary_table(summary_lines)
    parsed['operating_cost'] = cost_candidates['operating_cost']
    parsed['heating_cost'] = cost_candidates['heating_cost']
    parsed['total_cost'] = cost_candidates['total_cost']

    for field_name, patterns in FIELD_LABELS.items():
        if field_name in ['operating_cost', 'heating_cost', 'total_cost'] and parsed[field_name] is not None:
            continue
        for pattern in patterns:
            if parsed[field_name] is not None:
                break
            stop_re = None
            if field_name == 'advance_payment':
                stop_re = r'Nachzahlung|Guthaben|Ergebnis|Abrechnungsergebnis|Bitte|Die der Abrechnung|Ihre Kostenanteil|Ihre Vorauszahlungen|Nach Ergebnis'
            elif field_name == 'credit':
                stop_re = r'Bitte|Die der Abrechnung|Auf unser Konto|Ihr Betrag|Ihre Vorauszahlung|Ihre Vorauszahlungen|Nachzahlung|Ergebnis|Abrechnungsergebnis'
            elif field_name == 'debit':
                stop_re = r'Guthaben|Ergebnis|Abrechnungsergebnis|Bitte|Die der Abrechnung|Ihre Vorauszahlung|Ihre Vorauszahlungen'
            parsed[field_name] = find_amount_for_label(summary_lines, pattern, prefer_last=(field_name in ['advance_payment', 'credit', 'debit']), max_lookahead=6, stop_re=stop_re)

    if parsed['operating_cost'] is None or parsed['heating_cost'] is None:
        cost_amounts = find_amounts_after_anchor(summary_lines, r'Vorauszahlungsart.*Ihre Gesamtkosten|Ihre Gesamtkosten', min_amounts=2)
        if len(cost_amounts) >= 2:
            parsed['operating_cost'] = parsed['operating_cost'] or cost_amounts[0]
            parsed['heating_cost'] = parsed['heating_cost'] or cost_amounts[1]

    advance_rows = get_label_block_amount_rows(
        summary_lines,
        r'Vorauszahlung|Vorauszahl|Vorausrw',
        stop_re=r'Guthaben|Nachzahlung|Ergebnis|Abrechnungsergebnis|Bitte|Die der Abrechnung|Ihre Kostenanteil',
        max_lookahead=8,
    )
    if advance_rows:
        parsed['advance_payment'] = parsed['advance_payment'] or choose_total_from_amount_rows(advance_rows)

    # For newer table-style summaries we can parse inline rows after header anchors.
    if parsed['operating_cost'] is None or parsed['heating_cost'] is None:
        table_rows = extract_amount_table_after_anchor(
            summary_lines,
            r'Vorauszahlungsart.*Ihre Gesamtkosten|Ihre Gesamtkosten',
            stop_re=r'Abrechnungsergebnis|Ihre Vorauszahlung|Nachzahlung|Guthaben',
            min_rows=2,
            max_lookahead=8,
        )
        if len(table_rows) >= 2:
            if parsed['operating_cost'] is None and len(table_rows[0]) >= 1:
                parsed['operating_cost'] = table_rows[0][0]
            if parsed['heating_cost'] is None and len(table_rows[1]) >= 1:
                parsed['heating_cost'] = table_rows[1][0]

    if parsed['total_cost'] is None:
        table_rows = extract_amount_table_after_anchor(
            summary_lines,
            r'Vorauszahlungsart.*Ihre Gesamtkosten|Ihre Gesamtkosten',
            stop_re=r'Abrechnungsergebnis|Ihre Vorauszahlung|Nachzahlung|Guthaben',
            min_rows=3,
            max_lookahead=8,
        )
        if len(table_rows) >= 3 and len(table_rows[2]) >= 1:
            parsed['total_cost'] = table_rows[2][0]

    advance_rows = extract_amount_table_after_anchor(
        summary_lines,
        r'Ihre Vorauszahlung|Vorauszahlung|Vorauszahl|Vorausrw',
        stop_re=r'Nachzahlung|Guthaben|Ergebnis|Abrechnungsergebnis|Bitte|Die der Abrechnung',
        min_rows=1,
        max_lookahead=8,
    )
    advance_value = choose_advance_total(advance_rows)
    if advance_value is not None:
        parsed['advance_payment'] = parsed['advance_payment'] or advance_value

    credit_rows = extract_amount_table_after_anchor(
        summary_lines,
        r'Guthaben',
        stop_re=r'Bitte|Die der Abrechnung|Auf unser Konto|Ihr Betrag|Ihre Vorauszahlung|Nachzahlung|Ergebnis|Abrechnungsergebnis',
        min_rows=1,
        max_lookahead=6,
    )
    if credit_rows:
        parsed['credit'] = parsed['credit'] or choose_last_total(credit_rows)

    debit_rows = extract_amount_table_after_anchor(
        summary_lines,
        r'Nachzahlung|Nachzahrung',
        stop_re=r'Guthaben|Ergebnis|Abrechnungsergebnis|Bitte|Die der Abrechnung|Ihre Vorauszahlung',
        min_rows=1,
        max_lookahead=6,
    )
    if debit_rows:
        parsed['debit'] = parsed['debit'] or choose_last_total(debit_rows)
        if parsed['debit'] is not None and parsed['debit'] < 0:
            parsed['debit'] = abs(parsed['debit'])

    result_rows = extract_amount_table_after_anchor(
        summary_lines,
        r'\bAbrechnungsergebnis\b|\bNach Ergebnis\b',
        stop_re=r'Guthaben|Bitte|Die der Abrechnung|Ihre Vorauszahlung|Ihre Nachzahlung|Summe Gesamtkosten',
        min_rows=1,
        max_lookahead=6,
    )
    if result_rows:
        candidate_result = choose_last_total(result_rows)
        if candidate_result is not None and not (
            parsed['operating_cost'] is not None and abs(candidate_result - parsed['operating_cost']) < 1.00
            or parsed['heating_cost'] is not None and abs(candidate_result - parsed['heating_cost']) < 1.00
            or parsed['total_cost'] is not None and abs(candidate_result - parsed['total_cost']) < 1.00
        ):
            parsed['result'] = parsed['result'] or candidate_result

    if parsed['total_cost'] is None and parsed['operating_cost'] is not None and parsed['heating_cost'] is not None:
        parsed['total_cost'] = parsed['operating_cost'] + parsed['heating_cost']

    if parsed['total_cost'] is not None and parsed['operating_cost'] is not None and parsed['heating_cost'] is not None:
        if abs(parsed['total_cost'] - parsed['operating_cost']) < 0.01 or abs(parsed['total_cost'] - parsed['heating_cost']) < 0.01:
            parsed['total_cost'] = parsed['operating_cost'] + parsed['heating_cost']

    if parsed['result'] is None:
        if parsed['credit'] is not None:
            parsed['result'] = parsed['credit']
        elif parsed['debit'] is not None:
            parsed['result'] = -parsed['debit']

    return parsed


def extract_text(pdf_path: str) -> str:
    reader = PdfReader(pdf_path)
    text_pages = []
    for page in reader.pages:
        page_text = page.extract_text() or ''
        if page_text:
            text_pages.append(page_text)
    return '\n'.join(text_pages)


def analyze_year_file(pdf_path: str) -> dict:
    year_match = PDF_PATTERN.match(os.path.basename(pdf_path))
    if not year_match:
        raise ParseError(f'Unable to extract year from filename: {pdf_path}')
    year = int(year_match.group(1))

    text = extract_text(pdf_path)
    fields = parse_summary_fields(text)
    amounts = []
    for m in CURRENCY_RE.finditer(text):
        value = parse_money(m.group(1))
        if value is not None:
            amounts.append(value)

    return {
        'year': year,
        'pdf_path': pdf_path,
        'fields': fields,
        'amounts_found': len(amounts),
        'amounts_sample': amounts[:12],
        'raw_text_length': len(text),
    }


def safe_ratio(value: Optional[float], baseline: Optional[float]) -> Optional[float]:
    if value is None or baseline is None or baseline == 0:
        return None
    return value / baseline


def format_money(value: Optional[float]) -> str:
    if value is None:
        return 'MISSING'
    return f'{value:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')


def detect_inconsistencies(record: dict) -> list[str]:
    fields = record['fields']
    issues = []
    op = fields['operating_cost']
    heat = fields['heating_cost']
    total = fields['total_cost']
    advance = fields['advance_payment']
    credit = fields['credit']
    debit = fields['debit']
    result = fields['result']

    if op is not None and heat is not None and total is not None:
        sum_costs = op + heat
        diff = abs(sum_costs - total)
        if diff > 1.00:
            issues.append(f'SUM CHECK FAILED: Betriebskosten + Heizkosten = {sum_costs:.2f} €, Gesamtkosten = {total:.2f} € (Δ {diff:.2f} €)')
    elif any(field is None for field in [op, heat, total]):
        issues.append('SUMMARY INCOMPLETE: missing Betriebskosten, Heizkosten, or Gesamtkosten')

    if advance is not None and total is not None:
        expected_balance = advance - total
        if credit is not None and abs(expected_balance - credit) > 1.00:
            issues.append(f'EXPECTED BALANCE MISMATCH: Vorauszahlung - Gesamtkosten = {expected_balance:.2f} €, Guthaben = {credit:.2f} €')
        if debit is not None and abs(expected_balance + debit) > 1.00:
            issues.append(f'EXPECTED BALANCE MISMATCH: Vorauszahlung - Gesamtkosten = {expected_balance:.2f} €, Nachzahlung = {debit:.2f} €')
    elif result is not None and total is not None and advance is None:
        issues.append('PARTIAL BALANCE CHECK: Gesamtkosten found but Vorauszahlung missing')

    if record['amounts_found'] < 8:
        issues.append('LOW AMOUNT COUNT: extracted fewer than 8 euro amounts from the full PDF text')

    return issues


def summarize_cross_year(records: list[dict]) -> list[str]:
    messages = []
    sorted_records = sorted(records, key=lambda item: item['year'])
    for previous, current in zip(sorted_records, sorted_records[1:]):
        prev_total = previous['fields']['total_cost']
        cur_total = current['fields']['total_cost']
        if prev_total is not None and cur_total is not None:
            change = cur_total - prev_total
            pct = safe_ratio(change, prev_total)
            if pct is not None and abs(pct) >= 0.4:
                direction = 'increase' if change > 0 else 'decrease'
                messages.append(
                    f'YEAR-OVER-YEAR {direction.upper()}: {previous["year"]}->{current["year"]} Gesamtkosten {format_money(prev_total)} -> {format_money(cur_total)} ({pct*100:.1f}%)'
                )

        advance_prev = previous['fields']['advance_payment']
        advance_cur = current['fields']['advance_payment']
        if advance_prev is not None and advance_cur is not None:
            advance_pct = safe_ratio(advance_cur - advance_prev, advance_prev)
            if advance_pct is not None and abs(advance_pct) >= 0.5:
                direction = 'increase' if advance_cur > advance_prev else 'decrease'
                messages.append(
                    f'ADVANCE PAYMENT JUMP: {previous["year"]}->{current["year"]} Vorauszahlung {format_money(advance_prev)} -> {format_money(advance_cur)} ({advance_pct*100:.1f}%)'
                )
    return messages


def main() -> None:
    pdf_files = [os.path.join(BASE_DIR, name) for name in os.listdir(BASE_DIR) if PDF_PATTERN.match(name)]
    if not pdf_files:
        raise SystemExit('No OCR PDF files found in the workspace matching Betriebskosten_*_OCR.pdf')

    records = []
    for pdf_path in sorted(pdf_files):
        print(f'Processing {os.path.basename(pdf_path)}')
        try:
            record = analyze_year_file(pdf_path)
            records.append(record)
        except Exception as exc:
            print(f'  ERROR: {exc}')

    records.sort(key=lambda item: item['year'])
    summary = []
    for record in records:
        year = record['year']
        fields = record['fields']
        summary.append({
            'year': year,
            'operating_cost': fields['operating_cost'],
            'heating_cost': fields['heating_cost'],
            'total_cost': fields['total_cost'],
            'advance_payment': fields['advance_payment'],
            'credit': fields['credit'],
            'debit': fields['debit'],
            'result': fields['result'],
            'issues': detect_inconsistencies(record),
        })

    print('\n--- Summary by year ---')
    for item in summary:
        print(f"{item['year']}: Betriebskosten={format_money(item['operating_cost'])}, Heizkosten={format_money(item['heating_cost'])}, Gesamtkosten={format_money(item['total_cost'])}, Vorauszahlung={format_money(item['advance_payment'])}, Guthaben={format_money(item['credit'])}, Nachzahlung={format_money(item['debit'])}")
        if item['issues']:
            for issue in item['issues']:
                print('  -', issue)

    cross_year = summarize_cross_year(records)
    if cross_year:
        print('\n--- Cross-year anomalies ---')
        for message in cross_year:
            print(' -', message)
    else:
        print('\nNo strong cross-year anomalies detected by the current heuristic.')

    report_path = os.path.join(BASE_DIR, f'analysis_report_{datetime.now():%Y%m%d_%H%M%S}.json')
    report = {
        'generated_at': datetime.now().isoformat(),
        'records': records,
        'summary': summary,
        'cross_year_flags': cross_year,
    }
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f'\nSaved analysis report to {report_path}')


if __name__ == '__main__':
    main()
