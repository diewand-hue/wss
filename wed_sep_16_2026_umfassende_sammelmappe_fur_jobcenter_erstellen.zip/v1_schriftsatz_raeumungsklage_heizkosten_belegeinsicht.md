# Schriftsatz zur Räumungsklage

**An das Amtsgericht [Ort]**  
**Az.: [Aktenzeichen]**

In dem Rechtsstreit  
**[Name Kläger] ./. [Ihr Name]**

wird zur Begründung des bisherigen Vorbringens und zur Erwiderung auf die geltend gemachten Zahlungsrückstände ergänzend wie folgt vorgetragen:

## 1. Streitige Heiz- und Warmwasserkosten

Die Klägerseite stützt die geltend gemachten Rückstände jedenfalls teilweise auf Nachforderungen aus Heizkosten-, Warmwasserkosten- und/oder Betriebskostenabrechnungen. Diese Forderungen werden ausdrücklich bestritten, soweit sie auf nicht überprüfbaren oder technisch auffälligen Verbrauchswerten beruhen.[cite:48][cite:53]

Der Beklagtenseite wurde trotz wiederholter Aufforderung keine vollständige Belegeinsicht gewährt. Das betrifft insbesondere nicht nur Rechnungen, sondern auch Zahlungsbelege, Ableseunterlagen, Verbrauchsaufstellungen, Abrechnungsgrundlagen, ggf. Reparatur- und Wartungsnachweise sowie sonstige Unterlagen, die zur Überprüfung der Abrechnung erforderlich sind.[cite:46][cite:39][cite:57]

Nach der Rechtsprechung des Bundesgerichtshofs umfasst das Einsichtsrecht des Mieters grundsätzlich die Originalbelege; ein besonderes Interesse muss hierfür nicht dargelegt werden.[cite:46][cite:50] Solange der Vermieter einem berechtigten Verlangen auf Belegvorlage nicht nachkommt, ist eine auf diese Abrechnung gestützte Nachforderung nicht durchsetzbar bzw. kann zurückbehalten werden.[cite:48][cite:53][cite:55]

## 2. Technische Auffälligkeiten bei Warmwasser und Heizungsregelung

Hinzu kommen erhebliche Zweifel an der sachlichen Richtigkeit der Verbrauchserfassung. Seit einem Besuch der Klägerseite unter dem Vorwand einer Modernisierung wurden vorhandene Regulierungsthermostate entfernt. Thermostatventile dienen der raumweisen Temperaturregelung und der Energieeinsparung; ihre technische Funktion ist allgemein anerkannt.[cite:37][cite:56]

Seit diesem Eingriff dreht sich die Warmwassermessuhr dauerhaft, wenn auch langsam, weiter. Im auf den Eingriff folgenden Abrechnungszeitraum stieg der abgerechnete Warmwasserverbrauch nach der vorliegenden Darstellung auf etwa das Doppelte des Vorjahres, ohne dass eine entsprechende Nutzungsänderung auf Beklagtenseite erfolgt wäre. Dies begründet jedenfalls den konkreten Verdacht einer fehlerhaften Verbrauchserfassung, eines technischen Defekts oder einer fehlerhaften Anlagenkonfiguration.[cite:33][cite:48]

Die Klägerseite ist deshalb gehalten, die Richtigkeit der angesetzten Verbrauchswerte, die ordnungsgemäße Erfassung sowie die technische Funktionsfähigkeit der betroffenen Mess- und Regelungseinrichtungen substantiiert nachzuweisen.[cite:48][cite:57]

## 3. Fehlende Nachweise

Die Beklagtenseite hat wiederholt Nachweise angefordert, insbesondere:

- vollständige Belege zu den Heiz- und Warmwasserkosten,
- Zahlungsbelege,
- Ableseprotokolle,
- Verbrauchsaufstellungen,
- Angaben zur Ermittlung des Gesamtverbrauchs,
- Unterlagen zu Eingriffen an der Heizungs- bzw. Warmwasseranlage,
- Reparatur-, Wartungs- oder Arbeitsberichte im Zusammenhang mit der behaupteten Modernisierung.

Diese Unterlagen wurden bislang nicht oder nicht vollständig vorgelegt.[cite:39][cite:46][cite:48]

Gerade bei verbrauchsabhängigen Kosten ist die Einsicht in die zugrunde liegenden Verbrauchsdaten und Abrechnungsunterlagen erforderlich, um die Plausibilität der angesetzten Werte sowie die Verteilung der Kosten prüfen zu können.[cite:48][cite:53]

## 4. Prozessuale Folgerung

Soweit die Räumungsklage auf behauptete Rückstände aus den genannten Abrechnungen gestützt wird, fehlt es jedenfalls derzeit an einer tragfähigen Grundlage für die Annahme fälliger und zutreffend berechneter Zahlungsrückstände.[cite:48][cite:53][cite:55]

Die behaupteten Forderungen sind bestritten. Die Abrechnungen sind mangels vollständiger Belegeinsicht und wegen der dargelegten technischen Auffälligkeiten nicht ausreichend überprüfbar. Die auf dieser Grundlage behaupteten Rückstände können daher der Räumungsklage nicht ohne Weiteres zugrunde gelegt werden.[cite:46][cite:48][cite:53]

## 5. Anträge und Anregungen

Es wird angeregt,

- den Kläger zur Vorlage sämtlicher abrechnungsrelevanter Unterlagen zu den streitigen Heiz-, Warmwasser- und Betriebskosten aufzufordern,
- insbesondere Rechnungen, Zahlungsbelege, Ableseunterlagen, Verbrauchsaufstellungen und Unterlagen zu Eingriffen an der Anlage beizuziehen,
- die behaupteten Zahlungsrückstände aus den streitigen Abrechnungen nicht als unstreitig oder fällig zu behandeln,
- den Sachvortrag der Beklagtenseite zur fehlerhaften Verbrauchserfassung und zu den Veränderungen an der Anlage in die Beweiswürdigung einzubeziehen.

Für den Fall des Bestreitens wird auf die Vorlage von Lichtbildern, Protokollaufzeichnungen, Schriftverkehr und weiteren Unterlagen Bezug genommen.

**[Ort], [Datum]**  
**[Name]**

## Anlagenübersicht

- Anlage B1: Schriftverkehr zur Belegeinsicht
- Anlage B2: Betriebskostenabrechnung(en)
- Anlage B3: Heiz-/Warmwasserkostenabrechnung(en)
- Anlage B4: Verbrauchsvergleich Vorjahr/Folgejahr
- Anlage B5: Fotos/Videos/Protokolle zum Warmwasserzähler
- Anlage B6: Schriftverkehr zur behaupteten Modernisierung / zum Ausbau der Thermostate
