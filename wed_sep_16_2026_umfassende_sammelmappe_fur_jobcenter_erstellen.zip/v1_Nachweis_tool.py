"""Korrespondenz und Dateien als Nachweise indexieren.

Beispiele in Juno:
    python nachweis_tool.py eingang
    python nachweis_tool.py eingang --suche "rechnung,frist,widerspruch"
    python nachweis_tool.py eingang --modus move

Lege die zu prüfenden Dateien relativ zu diesem Skript in den Ordner
``eingang/``. Die Ergebnisse entstehen in ``nachweise/``.
"""

from __future__ import annotations

import argparse
import csv
import html
import re
import shutil
from datetime import datetime
from email import policy
from email.header import decode_header, make_header
from email.parser import BytesParser
from email.utils import parsedate_to_datetime
from pathlib import Path


TEXT_EXTENSIONS = {".txt", ".csv", ".md", ".log"}


def safe_name(name: str) -> str:
    """Erzeugt einen für Dateinamen geeigneten, kurzen Text."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
    name = re.sub(r"\s+", " ", name).strip(" .")
    return name[:80] or "datei"


def decode(value: str | None) -> str:
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except Exception:
        return value


def html_to_text(value: str) -> str:
    value = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", value)
    value = re.sub(r"(?s)<[^>]+>", " ", value)
    return html.unescape(re.sub(r"\s+", " ", value)).strip()


def email_details(path: Path) -> dict[str, object]:
    """Liest die wichtigsten E-Mail-Felder, Text und Anhänge aus einer EML."""
    with path.open("rb") as file:
        message = BytesParser(policy=policy.default).parse(file)

    parts: list[str] = []
    attachments: list[tuple[str, bytes]] = []
    for part in message.walk():
        if part.is_multipart():
            continue
        filename = part.get_filename()
        disposition = part.get_content_disposition()
        content_type = part.get_content_type()
        payload = part.get_payload(decode=True) or b""

        if filename or disposition == "attachment":
            attachments.append((safe_name(decode(filename) or "anhang"), payload))
        elif content_type in {"text/plain", "text/html"}:
            try:
                text = part.get_content()
            except Exception:
                text = payload.decode(part.get_content_charset() or "utf-8", "replace")
            parts.append(html_to_text(text) if content_type == "text/html" else text.strip())

    date_text = decode(message.get("Date"))
    try:
        date = parsedate_to_datetime(date_text).astimezone().replace(tzinfo=None)
    except (TypeError, ValueError, IndexError):
        date = datetime.fromtimestamp(path.stat().st_mtime)

    return {
        "date": date,
        "sender": decode(message.get("From")),
        "recipient": decode(message.get("To")),
        "subject": decode(message.get("Subject")) or "(ohne Betreff)",
        "text": "\n".join(part for part in parts if part),
        "attachments": attachments,
    }


def text_from_file(path: Path) -> str:
    if path.suffix.lower() in TEXT_EXTENSIONS:
        return path.read_text(encoding="utf-8", errors="replace")
    return ""


def matches(path: Path, terms: list[str], email: dict[str, object] | None) -> bool:
    if not terms:
        return True
    searchable = path.name
    if email:
        searchable += " " + " ".join(
            str(email[key]) for key in ("sender", "recipient", "subject", "text")
        )
    else:
        searchable += " " + text_from_file(path)
    searchable = searchable.casefold()
    return any(term.casefold() in searchable for term in terms)


def iter_input_files(source: Path, destination: Path):
    destination = destination.resolve()
    for path in source.rglob("*"):
        if path.is_file() and destination not in path.resolve().parents:
            yield path


def write_email_text(destination: Path, number: str, details: dict[str, object]) -> None:
    readable = (
        f"Nachweis: {number}\n"
        f"Datum: {details['date']:%Y-%m-%d %H:%M}\n"
        f"Von: {details['sender']}\n"
        f"An: {details['recipient']}\n"
        f"Betreff: {details['subject']}\n\n"
        f"{details['text']}\n"
    )
    destination.write_text(readable, encoding="utf-8")


def index(source: Path, destination: Path, terms: list[str], mode: str) -> int:
    destination.mkdir(parents=True, exist_ok=True)
    attachment_dir = destination / "anhaenge"
    rows: list[dict[str, str]] = []

    candidates = sorted(iter_input_files(source, destination), key=lambda item: item.name.casefold())
    for path in candidates:
        details = email_details(path) if path.suffix.lower() == ".eml" else None
        if not matches(path, terms, details):
            continue

        number = f"N{len(rows) + 1:03d}"
        date = details["date"] if details else datetime.fromtimestamp(path.stat().st_mtime)
        label = safe_name(str(details["subject"])) if details else safe_name(path.stem)
        target = destination / f"{number}_{label}{path.suffix.lower()}"
        shutil.copy2(path, target)

        attachment_names: list[str] = []
        if details:
            write_email_text(destination / f"{number}_{label}_lesbar.txt", number, details)
            for position, (name, payload) in enumerate(details["attachments"], start=1):
                attachment_dir.mkdir(exist_ok=True)
                saved = attachment_dir / f"{number}_A{position:02d}_{name}"
                saved.write_bytes(payload)
                attachment_names.append(saved.name)

        rows.append(
            {
                "Nachweisindex": number,
                "Datum": date.strftime("%Y-%m-%d %H:%M"),
                "Typ": "E-Mail" if details else "Datei",
                "Absender": str(details["sender"]) if details else "",
                "Betreff_oder_Datei": str(details["subject"]) if details else path.name,
                "Originalpfad": str(path.relative_to(source)),
                "Exportdatei": target.name,
                "Anhaenge": "; ".join(attachment_names),
            }
        )
        if mode == "move":
            path.unlink()

    with (destination / "nachweisindex.csv").open("w", newline="", encoding="utf-8") as file:
        fields = [
            "Nachweisindex", "Datum", "Typ", "Absender",
            "Betreff_oder_Datei", "Originalpfad", "Exportdatei", "Anhaenge",
        ]
        writer = csv.DictWriter(file, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Erstellt einen Nachweisindex aus Dateien und E-Mails.")
    parser.add_argument("ordner", nargs="?", default="eingang", help="Quellordner, Standard: eingang")
    parser.add_argument(
        "--suche",
        default="",
        help='Kommagetrennte Suchbegriffe, z. B. "frist,rechnung"',
    )
    parser.add_argument(
        "--modus",
        choices=("copy", "move"),
        default="copy",
        help="copy bewahrt Originale (Standard); move entfernt sie nach dem Export.",
    )
    args = parser.parse_args()

    source = Path(args.ordner)
    if not source.is_dir():
        raise SystemExit(f"Quellordner nicht gefunden: {source}")
    terms = [term.strip() for term in args.suche.split(",") if term.strip()]
    count = index(source, Path("nachweise"), terms, args.modus)
    print(f"{count} Nachweise erstellt: nachweise/nachweisindex.csv")


if __name__ == "__main__":
    main()